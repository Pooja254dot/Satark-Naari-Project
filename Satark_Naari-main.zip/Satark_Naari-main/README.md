# Satark_Naari
Build an app in flutter for ensuring security of women
